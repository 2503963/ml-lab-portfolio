## Lab 01 – Data Cleaning & Engineering Pipelines

### 1. Project Objective
This lab establishes reproducible data pipelines to load, inspect, clean, and convert raw real-world data into reliable feature matrix formats ($X, y$) optimized for machine learning algorithms.

### 2. Dataset Processing Summaries
| Dataset | Problem Context | Records Before | Records After | Target Label | Essential Engineering Steps Applied |
| :--- | :--- | :---: | :---: | :--- | :--- |
| **Titanic Survival** | Binary Classification | 891 | 891 | `Survived` | Imputed `Age` (median), `Embarked` (mode); dropped `Cabin` column; stripped spaces. |
| **Telco Churn** | Binary Classification | 7043 | 7043 | `churn` | Coerced `TotalCharges` object type to float; imputed hidden missing fields using the median; standardized text cases. |
| **Student Performance**| Multiclass Classification| 1000 | 1000 | `performance_band`| Verified zero missing values; created composite target classes (`high/medium/low`). |
| **Heart Disease** | Binary Classification | 297 | 297 | `condition` | Decoded categorical integer array values into meaningful human-readable labels. |

### 3. Data Importance Justification
Raw data is notoriously messy. For instance, tree-based models like ID3 can easily misinterpret numerical codes meant to represent unique categories, and missing values can completely break mathematical algorithms like PCA or distance-based clustering. Cleaning ensures structural reliability before passing features into modeling blocks.