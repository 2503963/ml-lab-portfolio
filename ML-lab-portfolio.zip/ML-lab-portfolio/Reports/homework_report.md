# Homework Reflection Report: Comparative Data Quality Engineering
**Course:** Machine Learning Foundations  
**Author Portfolio Assignment Section:** Lab 01 Data Ingestion Analytics

---

### 1. Comparative Analysis of Structural Data Quality
Reviewing the four processed datasets highlights a clear contrast in structural quality between clinical collection records, commercial business exports, and simulated academic test environments:

* **The Structural Chaos of Commercial Logs (Telco & Titanic):** The Telco and Titanic datasets mirror common issues found in business databases. In the Telco dataset, numerical entries in `TotalCharges` were incorrectly parsed as generic objects due to empty string spacing (`" "`). Similarly, the Titanic dataset suffered from extreme missingness, requiring us to drop the `Cabin` column entirely because it was more than 75% empty.
* **The Precision of Clinical Records (Heart Disease):** The Cleveland Heart Disease dataset was structurally complete but suffered from an abstraction issue. Using raw integers to represent nominal clinical features limits model interpretability and risks confusing algorithms that expect continuous values.
* **The Clarity of Simulated Environments (Student Performance):** The Student Performance dataset arrived clean, with zero missing values or duplicate rows. It served as a helpful baseline for checking data integrity and building custom feature tracking rules.

### 2. Challenges Overcome and Systematic Resolutions
* **The Object-Type Numeric Trap:** Standard checking methods (`df.isna().sum()`) missed the blank spaces in Telco's `TotalCharges` column because a space character is technically treated as a valid string object. 
    * *Resolution:* Applying `pd.to_numeric(..., errors='coerce')` forced these hidden spaces into identifiable `NaN` values, which we could then systematically impute using the median.
* **Categorical Fragmentation:** Varied spacing and inconsistent casing across files threatened to distort downstream one-hot encoding matrices.
    * *Resolution:* Implemented automated `.str.strip().str.lower()` preprocessing operations across all object feature layers.

### 3. Critical Machine Learning Engineering Insights
Data cleaning is not a separate step; it directly shapes how down-stream machine learning algorithms behave. 
* Imputing missing values with the **median** rather than the mean preserves important data characteristics without introducing bias from extreme outliers. This directly helps split-based algorithms like Decision Trees find clean, reliable division boundaries.
* Mapping clinical indicators back into explicit categorical string formats changes how pandas handles data types. This ensures nominal features are correctly treated as independent categories during encoding, rather than being misinterpreted as continuous ordinal values.